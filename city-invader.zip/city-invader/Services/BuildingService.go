package Services

import (
	"bytes"
	"city-invader/Logger"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"strconv"
)

var AppUrl = "https://api.skenarios.com"
//var AppUrl = "https://api.staging.skenarios.dev"

type Building struct {
	BuildingId      string  `json:"buildingId"`
	Description     string  `json:"description"`
	Address         string  `json:"address"`
	PostalCode      string  `json:"postalCode"`
	City            string  `json:"city"`
	Country         string  `json:"country"`
	Floors          int64   `json:"floors"`
	FloorArea       int64   `json:"floorArea"`
	Latitude        float64 `json:"lat"`
	Longitude       float64 `json:"lon"`
	BuildYear       int     `json:"buildYear"`
	PolygonUniqueId string  `json:"polygonUniqueId"`
	BuildingName    string  `json:"name"`
	GroupId         string  `json:"groupId"`
	GroupName       string  `json:"groupName"`
	BuildingTypeId  int64   `json:"buildingTypeId"`
	HeatingId       int     `json:"heatingId"`
	ElectricityId   int     `json:"electricityId"`
}

func SendBuildingToSkenariosApp(building Building, token string, portfolioId int) int {
	method := "POST"
	var bearer = "Bearer " + token
	client := &http.Client{}
	jsonValue, err := json.Marshal(building)
	if err != nil {
		Logger.Error.Printf("Unable to marshal building struct to json:", err.Error())
		return 0
	}

	appUrl := AppUrl
	//appUrl := os.Getenv("APP_URL")
	req, err := http.NewRequest(method, appUrl+"/api/v1/portfolio/"+strconv.Itoa(portfolioId)+"/property", bytes.NewBuffer(jsonValue))
	if err != nil {
		Logger.Error.Printf("Request to app failed:", err.Error())
		return 0
	}
	req.Header.Add("Authorization", bearer)
	req.Header.Set("Content-Type", "application/json")
	res, err := client.Do(req)
	if err != nil {
		Logger.Error.Printf("Request to app failed:", err.Error())
		return 0
	}
	defer res.Body.Close()

	if res.StatusCode == 201 {
		Logger.Info.Printf("Added property with no issues")
		return 1
	} else if res.StatusCode == 400 {
		body, _ := ioutil.ReadAll(res.Body)
		Logger.Error.Printf("Body response is:", string(body))
		return 2
	} else {
		body, _ := ioutil.ReadAll(res.Body)
		Logger.Error.Printf("Body response is:", string(body))
		Logger.Error.Printf("Unable to add a building response status is:", res.StatusCode)
	}
	return 0
}

func DeleteGroup(portfolioId int, token string, groupId string) bool {
	method := "DELETE"
	var bearerToken = "Bearer " + token
	client := &http.Client{}

	appUrl := AppUrl
	//appUrl := os.Getenv("APP_URL")
	req, err := http.NewRequest(method, appUrl+"/api/v1/portfolio/"+strconv.Itoa(portfolioId)+"/group/"+groupId, nil)
	if err != nil {
		Logger.Error.Printf("Request to app failed:", err.Error())
		return false
	}
	req.Header.Add("Authorization", bearerToken)
	req.Header.Set("Content-Type", "application/json")

	res, err := client.Do(req)
	if err != nil {
		Logger.Error.Printf("Request to app failed:", err.Error())
		return false
	}
	defer res.Body.Close()

	if res.StatusCode == 201 || res.StatusCode == 200 {
		Logger.Info.Printf("Group successfully removed")
		return true
	} else {
		body, _ := ioutil.ReadAll(res.Body)
		Logger.Error.Printf("Body response is:", string(body))
		Logger.Error.Printf("Unable to delete group response status is:", res.StatusCode)
		return false
	}
}

func GetBuildingTypes(country string, token string) []BuildingPrototype {
	method := "GET"
	var bearerToken = "Bearer " + token
	client := &http.Client{}

	appUrl := AppUrl
	//appUrl := os.Getenv("APP_URL")
	req, err := http.NewRequest(method, appUrl+"/app/buildingPrototypes", nil)
	if err != nil {
		Logger.Error.Printf("Request to app failed:", err.Error())
		return nil
	}
	req.Header.Add("Authorization", bearerToken)
	req.Header.Set("Content-Type", "application/json")

	res, err := client.Do(req)
	if err != nil {
		Logger.Error.Printf("Request to app failed:", err.Error())
		return nil
	}
	defer res.Body.Close()

	body, _ := ioutil.ReadAll(res.Body)
	var buildingPrototypes []BuildingPrototype
	err = json.Unmarshal(body, &buildingPrototypes)
	if err != nil {
		Logger.Error.Printf("Unable to read a response from geoapify:{}", err.Error())
		return nil
	}
	return buildingPrototypes
}
