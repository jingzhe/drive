package Services

import (
	"city-invader/Logger"
	"context"
	"github.com/go-pg/pg/v10"
	"os"
	"strconv"
	"strings"
	"time"
)

type AddedCount struct {
	Added  int `json:"added"`
	Failed int `json:"failed"`
}

var buildingPrototypes []BuildingPrototype

type BuildingType struct {
	BuildingTypeId int64  `json:"buildingTypeId"`
	TypeCode       string `json:"typeCode"`
}

type BuildingPrototype struct {
	BuildingPrototypeId int64        `json:"buildingPrototypeId"`
	Name                string       `json:"name"`
	Country             string       `json:"country"`
	Type                BuildingType `json:"type"`
	BuildPeriodStart    string       `json:"buildPeriodStart"`
	BuildPeriodEnd      string       `json:"buildPeriodEnd"`
}

type Link struct {
	Prototype string
	Type      string
}

// Database model with specified table and coordinates set as a pg array
type PropertySum struct {
	tableName     struct{} `pg:"map_uk.property_sum, discard_unknown_columns"`
	PropertyId    int64
	PolygonId     int64
	Uprn          int64
	Toid          string
	AddressStreet string
	AddressNumber string
	PolygonArea   int64
	PostalCode    string
	City          string
	FloorArea     int64
	NbrFloors     int64
	BuildYear     int
	Purpose       string
	Country       string
	Latitude      float64 `pg:"-"`
	Longitude     float64 `pg:"-"`
}

type PropertyBuilding struct {
	tableName          struct{} `pg:"property_building, discard_unknown_columns"`
	PropertyBuildingId int64
	PolygonUniqueId    string
	AddressCountry     string
	Latitude           float64 `pg:"-"`
	Longitude          float64 `pg:"-"`
}

type Request struct {
	GeoJson          string `json:"geoJson"`
	PortfolioId      int    `json:"portfolioId"`
	Token            string `json:"token"`
	Country          string `json:"country"`
	HeatingId        int    `json:"heatingId"`
	ElectricityId    int    `json:"electricityId"`
	DefaultBuildYear int    `json:"defaultBuildYear"`
	Reimport         bool   `json:"reimport"`
}

type AddressRequest struct {
	Address string `json:"address"`
}

type CoordinatesResponse struct {
	Address   string  `json:"address"`
	Latitude  float64 `json:"latitude"`
	Longitude float64 `json:"longitude"`
}

var countOfAdded = 0
var countOfFailed = 0

func createConnection() *pg.DB {
	//Database url is taken from the env variable make sure its set before running the app
	//var databaseUri = os.Getenv("DATABASE_URI")
	//%23 stands for # go doesn't understand # in postgres connection strings
	opt, err := pg.ParseURL("postgres://skenarios_read:X5DQaHp%23x@eCl$OlmYoBgLIqhNrRQs32@environment-3.cmbxcm7zmeyv.eu-west-1.rds.amazonaws.com/environment")
	if err != nil {
		panic(err)
	}
	db := pg.Connect(opt)

	ctx := context.Background()

	if err := db.Ping(ctx); err != nil {
		Logger.Error.Printf("Unable to open a connection to the database:", err.Error())
		panic(err)
	}
	return db
}

func createConnectionProd() *pg.DB {
	//Database url is taken from the env variable make sure its set before running the app
	//var databaseUri = os.Getenv("DATABASE_URI")
	//%23 stands for # go doesn't understand # in postgres connection strings
	//opt, err := pg.ParseURL("postgres://u1d3njmd98qmem:p79b5c2488a116cacb5ec7dd9f991b4a7e17f676819e4430996cf0e477dac64aa@ec2-34-240-196-222.eu-west-1.compute.amazonaws.com:5432/da32s3id7mlssf")
	opt, err := pg.ParseURL("postgres://skenarios_read:X5DQaHp#x@eCl$OlmYoBgLIqhNrRQs32@environment-3.cmbxcm7zmeyv.eu-west-1.rds.amazonaws.com:5432/environment")
	if err != nil {
		panic(err)
	}
	db := pg.Connect(opt)

	ctx := context.Background()

	if err := db.Ping(ctx); err != nil {
		Logger.Error.Printf("Unable to open a connection to the database:", err.Error())
		panic(err)
	}
	return db
}

func FetchPropertyCount(geoJson string, country string) (error, int) {
	db := createConnection()
	defer db.Close()
	var property PropertySum
	count, err := db.Model(&property).DistinctOn("geom").Where("ST_intersects(geom, st_setsrid(st_geomfromgeojson(?), 4326))", geoJson).Where("country = ?", country).Where("floor_area is not null").Where("polygon_area BETWEEN 30 AND 1500").Count()
	if err != nil {
		Logger.Error.Printf("Unable to fetch count of properties:", err.Error())
		return err, 0
	}
	return nil, count
}

func CleanNullPurpose(geoJson string, country string) {
	Logger.Info.Printf("CleanNullPurpose start")
	db := createConnection()
	defer db.Close()
	var result string
	var properties []PropertySum
	var query = "select distinct on (geom) *,st_x(st_centroid(geom)) as longitude, ST_Y(st_centroid(geom)) as latitude from map_uk.property_sum p where ST_intersects(p.geom, st_setsrid(st_geomfromgeojson(?), 4326)) and p.country = ?  and p.floor_area is not null and p.polygon_area BETWEEN 30 AND 1500 and p.purpose is null "
	_, err := db.Query(&properties, query, geoJson, country)
	if err != nil {
		Logger.Error.Printf("Unable to fetch properties:", err.Error())
	}
	Logger.Info.Printf("GetProperties after query propertyBuildings size=%v", len(properties))
	for _, value := range properties {
		result = result + "\n" + strconv.FormatInt(value.PolygonId, 10)
	}
	f, _ := os.Create("./output.csv")
	defer f.Close()
	f.WriteString(result)
}

func FetchPropertyBuildingCount() (error, int) {
	db := createConnectionProd()
	defer db.Close()
	var property PropertyBuilding
	count, err := db.Model(&property).Where("address_country = 'UK'").Where("created > '2022-01-01'").Where("polygon_unique_id is not null").Count()
	if err != nil {
		Logger.Error.Printf("Unable to fetch count of properties:", err.Error())
		return err, 0
	}
	return nil, count
}

func GetPropertyBuildingsAndUpdate() {
	err, count := FetchPropertyBuildingCount()
	if err != nil {
		Logger.Error.Printf("Unable to fetch count of properties:", err.Error())
	}
	if count > 0 {
		if count > 100 {
			limitAmount := count / 10
			var offset = 0
			for i := 0; i < 11; i++ {
				go GetPropertyBuildingAndUpdate(offset, limitAmount)
				offset += limitAmount - 1
			}
		} else {
			go GetPropertyBuildingAndUpdate(0, 101)
		}
	}

}

func dividePage(total int, limit int) int {
	count := total / limit
	if total%limit != 0 {
		count++
	}
	return count
}

func getLimit(total int, current int, limit int) int {
	if total < (current + limit) {
		return total - current
	}
	return limit
}

func GetPropertiesAndSendToApp(request Request) {
	err, count := FetchPropertyCount(request.GeoJson, request.Country)
	Logger.Info.Printf("properties count=%v", count)
	if err != nil {
		Logger.Error.Printf("Unable to fetch count of properties:", err.Error())
	}
	buildingPrototypes = GetBuildingTypes(request.Country, request.Token)

	goroutineCount := 4
	countInGoroutine := dividePage(count, goroutineCount)
	var offset = 0
	for i := 0; i < goroutineCount; i++ {
		currentLimit := getLimit(count, i*countInGoroutine, countInGoroutine)
		Logger.Info.Printf("GetPropertiesBatch offset=%v, currentLimit=%v", offset, currentLimit)
		go GetPropertiesBatch(request, currentLimit, offset, i)
		offset += countInGoroutine
	}
}

func GetPropertiesBatch(request Request, total int, offset int, index int) {
	time.Sleep(time.Duration(index*200) * time.Second)
	pageLimit := 250
	pageCount := dividePage(total, pageLimit)
	myOffset := offset

	for i := 0; i < pageCount; i++ {
		currentLimit := getLimit(total, i*pageLimit, pageLimit)
		GetProperties(request, myOffset, currentLimit)
		myOffset += pageLimit
	}

}

func GetPropertyBuildingAndUpdate(offset int, limit int) {
	Logger.Info.Printf("GetPropertyBuildingAndUpdate start offset=%v, limit=%v", offset, limit)
	db := createConnectionProd()
	defer db.Close()
	var propertyBuildings []PropertyBuilding
	var query = "select location[0] as longitude, location[1] as latitude, property_building_id, polygon_unique_id from property_building pb where address_country = 'UK' and created > '2022-05-01' and polygon_unique_id is not null limit ? offset ? "
	_, err := db.Query(&propertyBuildings, query, limit, offset)
	if err != nil {
		Logger.Error.Printf("Unable to fetch properties:", err.Error())
	}
	envDb := createConnection()
	defer envDb.Close()
	Logger.Info.Printf("GetPropertyBuildingAndUpdate after query propertyBuildings size=%v", len(propertyBuildings))
	for _, value := range propertyBuildings {
		var property PropertySum
		var envQuery = "SELECT distinct on (geom) *,st_x(st_centroid(geom)) as longitude, ST_Y(st_centroid(geom)) as latitude FROM map_uk.property_sum as ps WHERE ST_intersects(st_setsrid(ST_MakePoint(?,?), 4326), ps.geom)  limit 1 "
		_, err := envDb.Query(&property, envQuery, value.Longitude, value.Latitude)
		if err == nil {
			var propertyBuilding PropertyBuilding
			updateQuery := "update property_building set polygon_unique_id=? where property_building_id=?"
			_, err = db.Query(&propertyBuilding, updateQuery, property.PolygonId, value.PropertyBuildingId)
			if err != nil {
				Logger.Error.Printf("Daaaarn couldn't update")
			}
		} else {
			Logger.Error.Printf("Daaaarn couldn't get polygon from sum")
		}
	}
}

func GetProperties(request Request, offset int, limit int) {
	Logger.Info.Printf("GetProperties start offset=%v, limit=%v", offset, limit)
	db := createConnection()
	defer db.Close()
	var properties []PropertySum
	var query = "select distinct on (geom) *,st_x(st_centroid(geom)) as longitude, ST_Y(st_centroid(geom)) as latitude from map_uk.property_sum p where ST_intersects(p.geom, st_setsrid(st_geomfromgeojson(?), 4326)) and p.country = ?  and p.floor_area is not null and p.polygon_area BETWEEN 30 AND 1500 order by geom limit ? offset ? "
	_, err := db.Query(&properties, query, request.GeoJson, request.Country, limit, offset)
	if err != nil {
		Logger.Error.Printf("Unable to fetch properties:", err.Error())
	}
	Logger.Info.Printf("GetProperties after query propertyBuildings size=%v", len(properties))
	for _, value := range properties {
		var building Building
		if value.Purpose == "111" && value.PolygonArea >= 38 && value.PolygonArea <= 500 ||
			value.Purpose == "1121" && value.PolygonArea >= 30 && value.PolygonArea <= 500 ||
			value.Purpose == "1122a" && value.PolygonArea >= 36 && value.PolygonArea <= 1500 ||
			value.Purpose != "1122r" && value.PolygonArea >= 30 && value.PolygonArea <= 1000 {

			building.BuildYear = value.BuildYear
			building.Address = strings.Replace(value.AddressStreet, "'", "", -1) + " " + value.AddressNumber
			building.Country = value.Country
			building.FloorArea = value.FloorArea
			building.Latitude = value.Latitude
			building.Longitude = value.Longitude
			building.City = value.City
			building.Floors = value.NbrFloors
			building.PolygonUniqueId = strconv.FormatInt(value.PolygonId, 10)
			building.PostalCode = value.PostalCode
			if value.AddressStreet != "" {
				building.BuildingId = strconv.FormatInt(value.PolygonId, 10) + "_" + building.Address
				building.BuildingName = strconv.FormatInt(value.PolygonId, 10) + "_" + building.Address
				building.GroupName = building.BuildingId + "_" + building.Address
				building.GroupId = building.BuildingId + "_" + building.Address
			} else {
				building.BuildingId = strconv.FormatInt(value.PolygonId, 10)
				building.BuildingName = strconv.FormatInt(value.PolygonId, 10)
				building.GroupName = building.BuildingId
				building.GroupId = building.BuildingId
			}
			var buildYearToUse int
			var defaultYear = false
			var defaultType = false
			if value.BuildYear != 0 {
				buildYearToUse = value.BuildYear
			} else if request.DefaultBuildYear != 0 {
				defaultYear = true
				buildYearToUse = request.DefaultBuildYear
			} else {
				defaultYear = true
				buildYearToUse = 1980
			}

			var typeCodeToUse string
			if request.Country == "UK" && (len(value.Purpose) == 0) {
				//detached house
				typeCodeToUse = "1122r"
				defaultType = true
			} else {
				typeCodeToUse = value.Purpose
			}

			for _, bType := range buildingPrototypes {
				if bType.Type.TypeCode == typeCodeToUse && bType.Country == request.Country {
					start, _ := strconv.Atoi(strings.Split(bType.BuildPeriodStart, "-")[0])
					end, _ := strconv.Atoi(strings.Split(bType.BuildPeriodEnd, "-")[0])
					if start <= buildYearToUse && end >= buildYearToUse {
						building.BuildingTypeId = bType.BuildingPrototypeId
						break
					}
				}
			}
			building.HeatingId = request.HeatingId
			if building.HeatingId == 0 {
				building.HeatingId = 11 //GAS_BOILER
			}
			if building.BuildingTypeId == 0 {
				building.BuildingTypeId = 21 // Terraced house
			}
			if building.FloorArea < 50 {
				building.FloorArea = 50
			}
			building.ElectricityId = request.ElectricityId
			var description = ""
			if defaultYear {
				description = "Default year is used:" + strconv.Itoa(buildYearToUse) + " "
			}
			if defaultType {
				description += "Default type is used:" + typeCodeToUse + " "
			}
			building.Description = description
			building.BuildYear = buildYearToUse
			PostBuilding(building, request)
		}
	}
}

func PostBuilding(building Building, request Request) {
	isAdded := SendBuildingToSkenariosApp(building, request.Token, request.PortfolioId)
	if isAdded == 1 {
		countOfAdded++
	} else if isAdded == 2 && request.Reimport {
		//lets remove old property and a new one
		isDeleted := DeleteGroup(request.PortfolioId, request.Token, building.GroupId)
		if isDeleted {
			PostBuilding(building, request)
		}
	} else {
		countOfFailed++
	}
}

func GetCount() AddedCount {
	var addedCount AddedCount
	addedCount.Added = countOfAdded
	addedCount.Failed = countOfFailed
	return addedCount
}
