package Services

import (
	"city-invader/Logger"
	"fmt"
	"github.com/valyala/fastjson"
	"io/ioutil"
	"net/http"
	"net/url"
)

func FetchCoordinatesForGivenAddress(address string) []float64 {
	var geoapifyKey = "0c106c6d00af4e03ba7ed8058b8138df"
	url := fmt.Sprintf("https://api.geoapify.com/v1/geocode/search?text=%s&apiKey=%s", url.QueryEscape(address), geoapifyKey)
	method := "GET"

	client := &http.Client{}
	req, err := http.NewRequest(method, url, nil)

	if err != nil {
		Logger.Error.Printf("Request to Geoapify failed:{}", err.Error())
		return nil
	}
	res, err := client.Do(req)
	if err != nil {
		Logger.Error.Printf("Request to Geoapify failed:{}", err.Error())
		return nil
	}
	defer res.Body.Close()
	var p fastjson.Parser

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		Logger.Error.Printf("Unable to read a response from geoapify:{}", err.Error())
		return nil
	}
	response, err := p.Parse(string(body))
	Logger.Info.Printf("weeelll:", string(body))
	if err != nil {
		Logger.Error.Printf("Unable to read a response from geoapify:{}", err.Error())
		return nil
	}
	var coordinates []float64
	if response.Exists("features") && len(response.GetArray("features")) > 0 {
		//ideally should check the confidence of a result but just to show that it works keeping it simple
		var confidence = response.GetArray("features")[0].Get("properties").Get("rank").GetFloat64("confidence")
		if confidence > 0.4 {
			var coordArray = response.GetArray("features")[0].Get("geometry").GetArray("coordinates")
			var lon, _ = coordArray[0].Float64()
			var lat, _ = coordArray[1].Float64()
			coordinates = append(coordinates, lon)
			coordinates = append(coordinates, lat)
		}
	}
	if len(coordinates) > 0 {
		return coordinates
	}
	return nil
}
