package Logger

import (
	"github.com/TwiN/go-color"
	"log"
	"os"
)

var (
	Warning *log.Logger
	Info    *log.Logger
	Error   *log.Logger
)

func init() {
	Info = log.New(os.Stderr, color.Gray+"INFO: ", log.Ldate|log.Ltime|log.Lshortfile)
	Warning = log.New(os.Stderr, color.Yellow+"WARNING: ", log.Ldate|log.Ltime|log.Lshortfile)
	Error = log.New(os.Stderr, color.Red+"ERROR: ", log.Ldate|log.Ltime|log.Lshortfile)
}
