package Handlers

import (
	"city-invader/Logger"
	"city-invader/Services"
	"encoding/json"
	"net/http"
	"strconv"
)

func FetchPropertiesCount(w http.ResponseWriter, r *http.Request) {
	Logger.Info.Printf("Fetching properties count")
	var request Services.Request
	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		Logger.Error.Printf("Unable to map the body to the Request:", err.Error())
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	err, count := Services.FetchPropertyCount(request.GeoJson, request.Country)
	if err != nil {
		Logger.Error.Printf("Unable to fetch teh count, internal error")
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte("Unable to fetch the count, internal error"))
	} else {
		w.WriteHeader(http.StatusCreated)
		w.Write([]byte(strconv.Itoa(count)))
	}
}

func CleanNullPurpose(w http.ResponseWriter, r *http.Request) {
	Logger.Info.Printf("Fetching properties count")
	var request Services.Request
	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		Logger.Error.Printf("Unable to map the body to the Request:", err.Error())
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	Services.CleanNullPurpose(request.GeoJson, request.Country)
	w.WriteHeader(http.StatusCreated)
	w.Write([]byte("ok"))
}

func GetSentCount(w http.ResponseWriter, r *http.Request) {
	count := Services.GetCount()
	w.WriteHeader(http.StatusCreated)
	resp, err := json.Marshal(count)
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte("Unable to fetch the count, internal error"))
	} else {
		w.WriteHeader(http.StatusOK)
		w.Write(resp)
	}
}

func SendProperties(w http.ResponseWriter, r *http.Request) {
	Logger.Info.Printf("Fetching properties count")
	var request Services.Request
	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		Logger.Error.Printf("Unable to map the body to the Request:", err.Error())
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	Services.GetPropertiesAndSendToApp(request)
	w.WriteHeader(http.StatusCreated)
	w.Write([]byte("ok"))
}

func DoTheMapping(w http.ResponseWriter, r *http.Request) {
	Services.GetPropertyBuildingsAndUpdate()
	w.WriteHeader(http.StatusCreated)
	w.Write([]byte("ok"))
}

func FindLocations(w http.ResponseWriter, r *http.Request) {
	Logger.Info.Printf("Going to try a location for a given address")
	var request []Services.AddressRequest
	err := json.NewDecoder(r.Body).Decode(&request)
	if err != nil {
		Logger.Error.Printf("Unable to map the body to the Request:", err.Error())
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	var coordResponse = make([]Services.CoordinatesResponse, len(request))
	for _, address := range request {
		response := Services.FetchCoordinatesForGivenAddress(address.Address)
		Logger.Info.Printf("found coordinates:", response)
		if response != nil {
			coordResponse = append(coordResponse, Services.CoordinatesResponse{address.Address, response[1], response[0]})
		} else {
			coordResponse = append(coordResponse, Services.CoordinatesResponse{address.Address, 0, 0})
		}
	}
	coordJson, err := json.Marshal(coordResponse)
	if err != nil {
		Logger.Error.Printf("Unable to serialise Coordination data")
		w.WriteHeader(http.StatusInternalServerError)
		w.Write([]byte("Unable to serialise Coordination data, internal error"))
	}
	w.WriteHeader(http.StatusCreated)
	w.Write(coordJson)
}
