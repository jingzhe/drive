package main

import (
	"city-invader/Handlers"
	"github.com/gorilla/handlers"
	"github.com/gorilla/mux"
	"log"
	"net/http"
)

func setupRoutes(router *mux.Router) {
	router.HandleFunc("/api/properties/count", Handlers.FetchPropertiesCount).Methods("POST")
	router.HandleFunc("/api/properties", Handlers.SendProperties).Methods("POST")
	router.HandleFunc("/api/properties/importing", Handlers.GetSentCount).Methods("GET")
	router.HandleFunc("/api/properties/map", Handlers.DoTheMapping).Methods("GET")
	router.HandleFunc("/api/properties/addresses", Handlers.FindLocations).Methods("POST")
	router.HandleFunc("/api/properties/clean", Handlers.CleanNullPurpose).Methods("POST")

}
func main() {
	headersOk := handlers.AllowedHeaders([]string{"Accept", "Accept-Language", "Content-Type", "Content-Language", "Origin"})
	originsOk := handlers.AllowedOrigins([]string{"http://localhost:8080"})
	methodsOk := handlers.AllowedMethods([]string{"GET", "HEAD", "POST", "PUT", "DELETE", "OPTIONS"})

	router := mux.NewRouter().StrictSlash(true)
	setupRoutes(router)
	log.Fatal(http.ListenAndServe(":8082", handlers.CORS(headersOk, originsOk, methodsOk)(router)))

}
